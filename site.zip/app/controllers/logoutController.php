<?php
defined('security') or die('Access denied'); // Add light protection against file access

// Logout
authData('delete');