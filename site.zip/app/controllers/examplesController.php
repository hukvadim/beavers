<?php
defined('security') or die('Access denied'); // Add light protection against file access

// Add class to body
$systemOption['bodyCssClass'] .= 'bg-light';