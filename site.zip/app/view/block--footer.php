<?php
	defined('security') or die('Access denied'); // Add light protection against file access
?>

<footer class="footer border-top">
	<div class="container d-flex flex-wrap justify-content-between align-items-center">
		<p class="text-muted lh-1 my-0 fz-12px">Copyright © 2023 <?=DOMAIN?>. All rights reserved.</p>
		<a href="#" class="text-muted lh-1 my-0 fz-12px animate">Developer Zakhar</a>
	</div>
</footer>