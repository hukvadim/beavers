<?php
	defined('security') or die('Access denied'); // Add light protection against file access
?>

<div class="page-content">
	<div class="container">
		<h1 class="page-title"><?=ucfirst($systemOption['page'])?> page</h1>
	</div>
</div>